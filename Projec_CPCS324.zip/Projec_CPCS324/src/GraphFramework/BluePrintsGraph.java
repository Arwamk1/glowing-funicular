/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFramework;
import PhoneNetworkApp.Line;
import PhoneNetworkApp.Office;

public  class BluePrintsGraph extends Graph {

    public BluePrintsGraph() {
    }
    
    
    public BluePrintsGraph(int veticeNo, int edgeNo, boolean isDigraph) {
        super(veticeNo, edgeNo, isDigraph);
    }

    @Override
    public Vertex createVertex(int label) {
        return new Office(label); //To change body of generated methods, choose Tools | Templates.
    }

@Override
    public Edge createEdge(Vertex source, Vertex target, int wieght) {
        return new Line(source, target, wieght); //To change body of generated methods, choose Tools | Templates.
    }
 
}
