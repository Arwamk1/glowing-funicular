/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFramework;

import PhoneNetworkApp.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.regex.Pattern;

public abstract class Graph {

    private int verticesNO;
    private int edgeNo;
    private boolean isDigraph= true;//= true
    private Vertex [] vertices;
    private Graph g;

    public Graph(int verticesNO, int edgeNo, boolean isDigraph) {
        this.verticesNO = verticesNO;
        this.edgeNo = edgeNo;
        this.isDigraph = isDigraph;
        this.vertices = new Vertex[verticesNO];
       
    }

    public Graph() {
    }
    public int getVerticesNo() {
        return verticesNO;
    }

    public void setVerticesNo(int verticesNO) {
        this.verticesNO = verticesNO;
    }

    public int getEdgesNo() {
        return edgeNo;
    }

    public void setEdgesNo(int edgeNo) {
        this.edgeNo = edgeNo;
    }

    public boolean isIsDiagraph() {
        return isDigraph;
    }

    public void setIsDiagraph(boolean isDigraph) {
        this.isDigraph = isDigraph;
    }

    public Vertex [] getVertices() {
        return vertices;
    }

    public void setVertices(Vertex [] vertices) {
        this.vertices = vertices;
    }
    

    public void makeGraph(int v, int e) {

        for (int i = 0; i < verticesNO; i++) {
            vertices[i] = createVertex(i);  
           // System.out.println(vertices[i].label);
        }
       
        for (int i = 1; i < verticesNO ; i++) {
            int randomWeight = (int) (1 + Math.random() * 20); //first generate random wight to assign it to the edge 
            addEdge(vertices[i-1].getLabel(), vertices[i].getLabel(), randomWeight); //then add that edge graph
        }
        //remove that V-1 edge from the total
        //the remaing edges is totalNumberEdge
        int totalNumberEdge = edgeNo -( verticesNO-1 );
        //create edges randomaly and add them
        int i = 0; //counter of edges 
        while( i <totalNumberEdge ){
            //randomly choose a source 
            int sourceLable = (int) (Math.random() * (verticesNO));
            //randomly choose a target 
            int targetLabel = (int) (Math.random() * (verticesNO));
            if (sourceLable == targetLabel ) {//if the source is equal to the 
                continue; 
            }
        
           // Avoid duplicate edge with the same source and target
    			for(int j=0; j < vertices[sourceLable].getAdjList().size(); j++) {
    				if(vertices[sourceLable].getAdjList().get(j).getTarget().getLabel() != targetLabel) {
    					
    					break; // break out of loop if vertexU and vertexV are not an edge.
    					
    				} // end of if statement
    			} 
  
        // if there was no self-loop vertex & none existing edge, add new edge & increment
    			addEdge(vertices[sourceLable].getLabel(), vertices[targetLabel].getLabel(), (int) (1 + Math.random() * 10));
				i++;
        }      
    
        

    }

    public boolean isDuplicated(int SourceId, int targetID) {
        return false;

    }

    
    public void readGraphFromFile(File inputGraph) throws FileNotFoundException {
       
            Scanner input = new Scanner(inputGraph); // Scanner to read from file
            
            String GraphType = input.nextLine(); // Is direct graph or not?
            
            if(GraphType.equalsIgnoreCase("digraph 0")) {
                isDigraph= false; // 0 == undirected graph
            }
            else if (GraphType.equalsIgnoreCase("digraph 1")) {
            	isDigraph = true; // 1 == directed graph
            }
            
    		int totalNumVertices= input.nextInt(); // Read  (Second Line) # Vertices 
    		int totalNumEdge= input.nextInt(); // Read (Still Second Line) # Edges 
    		
    		if(!isDigraph) {
    			totalNumEdge *= 2;
    		}
              		
            vertices = new Vertex[totalNumVertices];
           
            
            while(edgeNo < totalNumEdge) {
                char source = input.next().charAt(0);
                // covert it to Vertex type
                
                char target = input.next().charAt(0);
                // covert it to Vertex type
                int weight = input.nextInt();
               
                addEdge(source-65, target-65, weight); 
             
                
                                
            }
            input.close();


        
    }
    
    public Edge addEdge(int source, int target, int wieght) {

        Graph g =  new BluePrintsGraph();
        
        if(vertices[source] == null){
             verticesNO++;
           vertices[source] =  g.createVertex(source);
           
       
    }
        
          if(vertices[target] == null){
                     verticesNO++;
         vertices[target]=  g.createVertex(target);
                
        
    }
        Edge e = g.createEdge(vertices[source],vertices[ target], wieght);
        edgeNo++;
        vertices[source].getAdjList().add(e);
        

        if (isDigraph == false) {
            e = g.createEdge(vertices[target], vertices[source], wieght);
           edgeNo += 2;
           vertices [target].getAdjList().add(e);

        } 
        return e;

    }

    abstract Edge createEdge(Vertex source, Vertex target, int wieght) ;

    abstract Vertex createVertex(int label);

    public Vertex addVertex(int Vertex) {
     
      Vertex v = new Vertex(Vertex);
      
        return v;
 
    }

   
    
}