/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFramework;



public class Edge {
    
    private int weight;
    private Vertex source;
    private Vertex target;

    public Edge( Vertex source, Vertex target, int weight) {
        this.source = source;
        this.target = target;
         this.weight = weight;
    }
      public Vertex getSource() {
        return source;
    }

    public void setSource(Vertex source) {
        this.source = source;
    }

    public Vertex getTarget() {
        return target;
    }

    public void setTarget(Vertex target) {
        this.target = target;
    }


    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
     
     public void displayInfo(){
         System.out.println(" Edge Details: \nWeight: " + weight + "\nSource: " + source +" \nTarget: " + target);
    }

}
