/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFramework;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;

public class MHPrimAlg extends MSTalgorithm {

    private int cost = 0;

    Map<Integer, Integer> vertexVal;

    // Stores the Minimum spanning Tree
    List<Edge> result;

    public MHPrimAlg(Graph graph) {
        //super(graph);
        MSTresultList = new Edge[graph.getVerticesNo()]; // MST List

    }

    public void findMST(Graph graph) {

        vertexVal = new LinkedHashMap<>(); // to store vertex info (parent ,key)

        // Vertex to Edge Map
        Map<Integer, Edge> vertexToEdge = new HashMap<>(); //store the chosen edges with min weight

        // Assign all the initial values as infinity for all the Vertices.
        for (Vertex v : graph.getVertices()) {
            vertexVal.put(v.getLabel(), Integer.MAX_VALUE);
        }

        MinHeap minHeap = new MinHeap(vertexVal); //minheap obj 

        //  create the MinHeap for vertcies
        minHeap.buildHeap();

        // Replace the value of start vertex to 0.
        minHeap.updateHeap(graph.getVertices()[0].getLabel(), 0);
        int encounter = 0;
        // Continue until the Min-Heap become empty.
        while (!minHeap.empty()) {
            // Extract minimum  vertex from Heap
            Integer currentVertex = minHeap.deleteMin();

            // Need to get the edge for the vertex and add it to the Minimum Spanning Tree..
            // Just note, the edge for the source vertex will not be added.
            Edge spanningTreeEdge = vertexToEdge.get(currentVertex);
            if (spanningTreeEdge != null) {
                //result.add(spanningTreeEdge);
                MSTresultList[encounter] = spanningTreeEdge;
                cost += MSTresultList[encounter].getWeight();
                encounter++;
            }

            // Get all the adjacent vertices 
            for (Edge e : getEdges(currentVertex, graph)) {
                Integer adjacentVertex = e.getTarget().getLabel();

                // We check if adjacent vertex exist in 'Map in Heap' and length of the edge is with this vertex
                // is greater than this edge length.
                if (minHeap.containsVertex(adjacentVertex) && minHeap.getWeight(adjacentVertex) > e.getWeight()) {

                    // Replace the edge length with this edge weight.
                    minHeap.updateHeap(adjacentVertex, e.getWeight());

                    vertexToEdge.put(adjacentVertex, e);
                }
            }
        }
    }

    List<Edge> getEdges(int vertex, Graph graph) {

        List<Edge> edgeList = new LinkedList<>();

        for (int j = 0; j < graph.getVertices().length; j++) {
            if (graph.getVertices()[j].getLabel() == vertex) {
                edgeList = graph.getVertices()[j].getAdjList();
            }
        }

        return edgeList;
    }


    public void displayResultingMST() {
        for (int i = 0; i < MSTresultList.length - 1; i++) {
            Vertex vf = MSTresultList[i].getSource();
            vf.displayInfo();
            System.out.print(" - ");
            Vertex vs = MSTresultList[i].getTarget();
            vs.displayInfo();
            System.out.print("");
            Edge e = MSTresultList[i];
            e.displayInfo();
            System.out.println();
        }

    }

    public void displayMSTcost() {
        System.out.println("The cost of designed phone network: " + this.cost);
    }
} // End of Class
