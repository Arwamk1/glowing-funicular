/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFramework;

/**
 *
 * @author 96650
 */
public class MSTalgorithm {
 Edge [] MSTresultList;

    public MSTalgorithm() {
    Edge [] MSTresultList =   this.MSTresultList;
    }
    

    public void findMST(Graph Graph) {

    }

    public void displayResultingMST() {

    } // End of Method

    public void displayMSTcost() {
        
    }
}
  


