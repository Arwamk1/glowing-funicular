/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFramework;

import java.util.LinkedList;


public class Vertex {
    
    private int label;
    private boolean isVisited= false; //= false
    private LinkedList<Edge> adjList; //remove []
    public Vertex() {
        adjList = new LinkedList<Edge>() ;
    }
    public Vertex(int label) {
        this.label = label;
        this.isVisited = false;
        adjList = new LinkedList<Edge>();
      
    }
    public int getLabel() {
        return label;
    }
    public void setLabel(int label) {
        this.label = label;
    }

    public boolean isIsVisited() {
        return isVisited;
    }

    public void setIsVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }

    public LinkedList<Edge> getAdjList() {
        return adjList;
    }

    public void displayInfo(){
      System.out.println(label);// not sure
    }
}
