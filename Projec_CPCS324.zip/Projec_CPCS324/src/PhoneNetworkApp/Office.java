/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PhoneNetworkApp;
import GraphFramework.Vertex;

public class Office extends Vertex{
    

	private String city ;

	public Office(int label) {
		super(label);
		this.city = String.valueOf((char)(label+65));
	}
	// Methods
	
	@Override
    public void displayInfo() {
		System.out.print("Office No. " + city);
    } // End of method

} // End of class