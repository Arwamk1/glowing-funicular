/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PhoneNetworkApp;
import GraphFramework.Edge;
import GraphFramework.Vertex;

public class Line extends Edge {

	    private int Routelength;
		
		public Line(Vertex source, Vertex target, int weight) {
			super(source, target, weight);
			this.Routelength = weight*3;
		} // End of Method
		
	    // Methods
	    @Override
	     public void displayInfo() {
	    	System.out.print(" : line length: " +  Routelength);
	    } // End of Method
	
	} // End of Class